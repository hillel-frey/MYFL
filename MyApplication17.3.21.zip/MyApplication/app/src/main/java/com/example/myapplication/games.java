package com.example.myapplication;

public class games {
    private String team1;
    private  String team2;
    private int score_team1;
    private int score_team2;
    private String date;
    private int time;
    private int week;
    private String channel;
    public games(Dal dal){}
    public games(String team1, String team2, int score_team1, int score_team2, String date, int time, int week, String channel)
    {
        this.team1 = team1;
        this.team2 = team2;
        this.score_team1 = score_team1;
        this.score_team2 = score_team2;
        this.date = date;
        this.time = time;
        this.week = week;
        this.channel = channel;
    }
    public String getTeam1()
    {
        return this.team1;
    }
    public String getTeam2()
    {
        return this.team2;
    }
    public int getScore_team1()
    {
        return this.score_team1;
    }
    public int getScore_team2()
    {
        return this.score_team2;
    }
    public String getDate()
    {
        return this.date;
    }
    public String getChannel()
    {
        return this.channel;
    }
    public int getTime()
    {
        return this.time;
    }
    public int getWeek()
    {
        return this.week;
    }
    public  void setTeam1(String team1)
    {
        this.team1 = team1;
    }
    public void setTeam2(String team2)
    {
        this.team2 = team2;
    }
    public void setScore_team1(int score_team1)
    {
        this.score_team1 = score_team1;
    }
    public void setScore_team2(int score_team2)
    {
        this.score_team2 = score_team2;
    }
    public  void setDate(String date)
    {
        this.date = date;
    }
    public  void setTime(int time)
    {
        this.time = time;
    }
    public  void setWeek(int week)
    {
        this.week = week;
    }
    public void setChannel(String channel)
    {
        this.channel = channel;
    }
    @Override
    public String toString()
    {
        return this.team1 +" VS. "+this.team2 + '/'+
           this.score_team1+ " : "+ this.score_team2+ '/'+
               this.date +" "+ this.time+ '/'+
               this.week +" "+ this.channel;
    }
}
