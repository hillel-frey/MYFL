package com.example.myapplication;

import android.media.Image;

public class teams {
    private String initials;
    private String city;
    private String name;

    public teams(){}
    public teams(String initials, String city, String name)
    {
        this.initials = initials;
        this.city = city;
        this.name = name;

    }
    public  String getInitials()
    {
        return this.initials;
    }
    public  String getCity()
    {
        return this.city;
    }
    public String getName()
    {
        return this.name;
    }
    public void setInitials(String initials)
    {
        this.initials = initials;
    }
    public  void setCity(String city)
    {
        this.city = city;
    }
    public  void setName(String name)
    {
        this.name = name;
    }
}
