package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    TextView tx;
    EditText et1, et2;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        tx = findViewById(R.id.textView4);
        et1 = findViewById(R.id.editTextTextEmailAddress2);
        et2 = findViewById(R.id.editTextTextPassword3);
        bt = findViewById(R.id.button4);
    }
    public void login(View v)
    {
        int k=0;
        Intent i = new Intent(LoginActivity.this, MainActivity.class);
        Intent in = new Intent(LoginActivity.this, GamesActivity.class);
        Dal dal = new Dal(this);
        ArrayList<users> use=dal.exist(et1.getText(), et2.getText());
        int x=use.size();
        for(int j=0;j<x;j++)
        {
            String st1=use.get(j).getEmail();
            String st2= use.get(j).getPassword();
//if(!st1.equals(null))
            if(st1.equals(et1.getText().toString()) && st2.equals(et2.getText().toString()))
            {
                k=1;
                startActivity(in);
            }



        }
        if(k==0)


            startActivity(i);



    }
}