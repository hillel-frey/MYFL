package com.example.myapplication;

public class weeks {
    private int week_number;
    public weeks(){}
    public  weeks(int week_number)
    {
        this.week_number = week_number;
    }
    public int getWeek_number()
    {
        return this.week_number;
    }
    public void setWeek(int num)
    {
        this.week_number = num;
    }

}
