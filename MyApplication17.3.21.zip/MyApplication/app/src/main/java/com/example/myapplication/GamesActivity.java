package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class GamesActivity extends AppCompatActivity {
ImageView img1, img2;
TextView tx1, tx2, tx3, tx4;
int i = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_games);
        img1 = findViewById(R.id.kc);
        img2 = findViewById(R.id.hou);
        tx1 = findViewById(R.id.datetime);
        tx2 = findViewById(R.id.weekchannel);
        tx3 = findViewById(R.id.teams);
        tx4 = findViewById(R.id.score);

    }
    public  void showallgames(View v)
    {
        Dal dal = new Dal(this);
        ArrayList<games> a = dal.browsegames();
        String team1 = a.get(i).getTeam1();
        String team2 = a.get(i).getTeam2();
        String channel = a.get(i).getChannel();
        String date = a.get(i).getDate();
        int score_team1 = a.get(i).getScore_team1();
        int score_team2 = a.get(i).getScore_team2();
        int week = a.get(i).getWeek();
        int time = a.get(i).getTime();
        tx1.setText(date + " " + time);
        tx2.setText(week + " " + channel);
        tx3.setText(team1 + " VS. " + team2);
        tx4.setText(score_team1 + " " + score_team2);
        String st1 = "a" + team2;
        int res = getResources().getIdentifier(team1, "drawable", this.getPackageName());
        img1.setImageResource(res);


        i++;
        if (i == a.size()) i = 0;

    }
}