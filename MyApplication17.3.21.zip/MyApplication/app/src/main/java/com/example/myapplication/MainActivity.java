package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button bt1, bt2;
    TextView tx;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt1 = findViewById(R.id.button);
        bt2 = findViewById(R.id.button2);
        tx = findViewById(R.id.textView3);
        img = findViewById(R.id.imageView2);
    }
    public  void gotoRegister(View v)
    {
        Intent in = new Intent(MainActivity.this, RegisterActivity.class);
        startActivity(in);
    }
    public void gotoLogin(View v)
    {
        Intent in = new Intent(MainActivity.this, LoginActivity.class);
        startActivity((in));
    }


}