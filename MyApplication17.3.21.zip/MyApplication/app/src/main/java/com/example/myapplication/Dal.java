package com.example.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.text.Editable;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;

public class Dal extends SQLiteAssetHelper {
    public Dal(Context context) {
        super(context, "project_365.db", null, 1);
    }
    public void addUser(String name, String email, String password)
    {
        SQLiteDatabase db;
        db = this.getWritableDatabase();
        String sql_INSERT = "INSERT INTO users(name, email, password) values(?,?,?)";
        SQLiteStatement statement = db.compileStatement(sql_INSERT);
        statement.bindString(1,name);
        statement.bindString(2, email);
        statement.bindString(3, password);
        statement.execute();
    }
    public ArrayList<users> exist(Editable email, Editable password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
     //   String e = email;
       // String s = password;
        String st = "SELECT email, password  FROM users ";
        ArrayList<users> ary = new ArrayList<>();
        Cursor cursor = db.rawQuery(st, null);
        while (cursor.moveToNext())
        {
            users u1=new users();
            String st1=cursor.getString(cursor.getColumnIndex("email"));
            String st2=cursor.getString(cursor.getColumnIndex("password"));
            u1.setEmail(st1);
            u1.setPassword(st2);
            ary.add(u1);



        }

return ary;
    }
    public ArrayList<games> browsegames()
    {

        String st = "select * from games";
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery(st, null);

        ArrayList<games> std = new ArrayList<>();

        while(cursor.moveToNext())

        {
            games g = new games(this);
            g.setTeam1(cursor.getString(cursor.getColumnIndex("team1")));
            g.setTeam2(cursor.getString(cursor.getColumnIndex("team2")));
            g.setScore_team1(cursor.getInt(cursor.getColumnIndex("score_team1")));
            g.setScore_team2(cursor.getInt(cursor.getColumnIndex("score_team2")));
            g.setChannel(cursor.getString(cursor.getColumnIndex("channel")));
            g.setDate(cursor.getString(cursor.getColumnIndex("date")));
            g.setTime(cursor.getInt(cursor.getColumnIndex("time")));
            g.setWeek(cursor.getInt(cursor.getColumnIndex("week")));

            std.add(g);

        }
        return std;

    }
}
